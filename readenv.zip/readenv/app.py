import sys

sys.path.append('E:/WORKPLACE/python/readenv/pydi')
from pydi.env_decorator import properties
from pydi.env_setting import load_propertis
class Test:

    def __init__(self):
        pass    

    @properties('application.db.name')    
    def get_application_name(self):
        pass


    def hello_get(self):
        print(self.get_application_name())


if __name__ == '__main__':
    load_propertis('E:/WORKPLACE/python/readenv/env.properties')
    test = Test()
    test.hello_get()
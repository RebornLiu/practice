import functools

import env_setting

def properties(text):

    def decerator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            return env_setting.get_application_env()[text]
        return wrapper
    return decerator
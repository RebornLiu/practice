class application_setting:

    def __init__(self):
        self.application_setting = {}

    def load_propertis(self, path):
        """
            读取本地的properties文件
        """
        f= open(path, 'r')
        lines = f.readlines()
        for line in lines:
            line = line.strip()
            if line.startswith('#'):
                continue
            values = line.split('=')
            self.application_setting[values[0]] = values[1]

    def read_property(self, key):
        return self.application_env[key]

def __find_setting_file(profile):
    """
    获取根目录 profile 文本文件按是application_profile.properties文件
    如果profile是空 则取application.properties文件
    """

if __name__ == '__main__':
    load_propertis('E:/WORKPLACE/python/readenv/env.properties')
    print(read_property('application.db.name'))